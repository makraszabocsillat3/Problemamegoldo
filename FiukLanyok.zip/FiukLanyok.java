import java.util.Scanner;

public class FiukLanyok {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine();

        String sor = sc.nextLine().trim();
        int hossz = sor.length();

        int hibakFKezzel = 0;
        int hibakLKezzel = 0;

        for (int i = 0; i < hossz; i++) {
            char valos = sor.charAt(i);
            char vartFMinta;
            if (i % 2 == 0) {
                vartFMinta = 'F';
            } else {
                vartFMinta = 'L';
            }
            if (valos != vartFMinta) {
                hibakFKezzel++;
            }

            char vartLMinta;
            if (i % 2 == 0) {
                vartLMinta = 'L';
            } else {
                vartLMinta = 'F';
            }
            if (valos != vartLMinta) {
                hibakLKezzel++;
            }
        }

        int cserekF = hibakFKezzel / 2;
        int cserekL = hibakLKezzel / 2;

        int eredmeny = Math.min(cserekF, cserekL);

        System.out.println(eredmeny);
    }
}
