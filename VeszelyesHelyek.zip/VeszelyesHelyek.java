import java.util.Scanner;
    public class VeszelyesHelyek {

        static int sorokSzama;
        static int oszlopokSzama;
        static int[][] palya;
        static int[][] megjegyzesTabla;

        public static int legjobbUtvonalInnen(int sor, int oszlop) {

            if (oszlop == oszlopokSzama - 1) {
                return palya[sor][oszlop];
            }
            if (megjegyzesTabla[sor][oszlop] != -1) {
                return megjegyzesTabla[sor][oszlop];
            }

            int legjobbEddig = Integer.MAX_VALUE;

            if (sor > 0) {
                int ertekFel = legjobbUtvonalInnen(sor - 1, oszlop + 1);
                legjobbEddig = Math.min(legjobbEddig, ertekFel);
            }

            int ertekKozep = legjobbUtvonalInnen(sor, oszlop + 1);
            legjobbEddig = Math.min(legjobbEddig, ertekKozep);

            if (sor < sorokSzama - 1) {
                int ertekLe = legjobbUtvonalInnen(sor + 1, oszlop + 1);
                legjobbEddig = Math.min(legjobbEddig, ertekLe);
            }

            int vegsoErtek = palya[sor][oszlop] + legjobbEddig;

            megjegyzesTabla[sor][oszlop] = vegsoErtek;

            return vegsoErtek;
        }

        public static int melyikSorbolInduljunk() {
            int legkisebbVeszely = Integer.MAX_VALUE;
            int legjobbSor = 0;

            for (int sor = 0; sor < sorokSzama; sor++) {
                int veszely = legjobbUtvonalInnen(sor, 0);

                if (veszely < legkisebbVeszely) {
                    legkisebbVeszely = veszely;
                    legjobbSor = sor;
                }
            }

            return legjobbSor + 1;
        }


        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            sorokSzama = sc.nextInt();
            oszlopokSzama = sc.nextInt();

            palya = new int[sorokSzama][oszlopokSzama];
            megjegyzesTabla = new int[sorokSzama][oszlopokSzama];

            for (int sor = 0; sor < sorokSzama; sor++) {
                for (int oszlop = 0; oszlop < oszlopokSzama; oszlop++) {
                    megjegyzesTabla[sor][oszlop] = -1;
                }
            }

            for (int sor = 0; sor < sorokSzama; sor++) {
                for (int oszlop = 0; oszlop < oszlopokSzama; oszlop++) {
                    palya[sor][oszlop] = sc.nextInt();
                }
            }
            System.out.println(melyikSorbolInduljunk());
        }
    }
