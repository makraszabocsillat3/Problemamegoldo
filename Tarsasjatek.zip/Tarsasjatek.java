import java.util.Scanner;

public class Tarsasjatek {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] ugras = new int[n + 1];

        for (int i = 1; i <= n; i++) {
            ugras[i] = sc.nextInt();
        }

        int nagy = Integer.MAX_VALUE / 2;
        int[] min = new int[n + 1];

        for (int i = 1; i <= n; i++) {
            min[i] = nagy;
        }
        min[1] = 0;

        for (int i = 1; i < n; i++) {
            if (min[i] == nagy) continue;

            if (min[i] + 1 < min[i + 1]) {
                min[i + 1] = min[i] + 1;
            }

            int cel = ugras[i];
            if (cel > i && cel <= n) {
                if (min[i] + 1 < min[cel]) {
                    min[cel] = min[i] + 1;
                }
            }
        }

        System.out.println(min[n]);
    }
}
