import java.util.Scanner;

public class FoldVasarlas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();

        int[] telkekAra = new int[n];
        for (int i = 0; i < n; i++) {
            telkekAra[i] = sc.nextInt();
        }

        long aktualisOsszeg = 0;
        for (int i = 0; i < k; i++) {
            aktualisOsszeg += telkekAra[i];
        }

        long legkisebbOsszeg = aktualisOsszeg;
        long darab = 1;

        for (int i = k; i < n; i++) {
            aktualisOsszeg -= telkekAra[i - k];
            aktualisOsszeg += telkekAra[i];

            if (aktualisOsszeg < legkisebbOsszeg) {
                legkisebbOsszeg = aktualisOsszeg;
                darab = 1;
            } else if (aktualisOsszeg == legkisebbOsszeg) {
                darab++;
            }
        }

        System.out.println(legkisebbOsszeg);
        System.out.println(darab);
    }
}
